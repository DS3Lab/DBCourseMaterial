﻿-- IMPORTANT: Replace PATH_TO_DATASET with the path to the Employee dataset

COPY employees FROM '/var/lib/postgresql/employee/data/employees.tbl' WITH delimiter AS '|';
COPY departments FROM '/var/lib/postgresql/employee/data/departments.tbl' WITH delimiter AS '|';
COPY dept_manager FROM '/var/lib/postgresql/employee/data/dept_manager.tbl' WITH delimiter AS '|';
COPY dept_emp FROM '/var/lib/postgresql/employee/data/dept_emp.tbl' WITH delimiter AS '|';
COPY titles FROM '/var/lib/postgresql/employee/data/titles.tbl' WITH delimiter AS '|';
COPY salaries FROM '/var/lib/postgresql/employee/data/salaries.tbl' WITH delimiter AS '|';
