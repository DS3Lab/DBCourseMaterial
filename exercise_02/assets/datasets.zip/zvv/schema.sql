
CREATE TABLE stops(
	stop_id bigint PRIMARY KEY,
	stop_name VARCHAR(40) NOT NULL,
	stop_lat FLOAT NOT NULL,
	stop_lon FLOAT NOT NULL);

CREATE TABLE trips(
	trip_id bigint PRIMARY KEY,
	tram_number INTEGER NOT NULL,
	trip_headsign VARCHAR(30) NOT NULL);

CREATE TABLE stop_times(
	trip_id bigint REFERENCES trips,
	arrival_time VARCHAR(9) NOT NULL,
	departure_time VARCHAR(9) NOT NULL,
	stop_id bigint REFERENCES stops,
	stop_sequence INTEGER NOT NULL,
	PRIMARY KEY (trip_id, stop_sequence));

