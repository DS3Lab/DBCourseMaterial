COPY stops FROM '/zvv/data/stops.tbl' WITH delimiter AS '|';
COPY trips FROM '/zvv/data/trips.tbl' WITH delimiter AS '|';
COPY stop_times FROM '/zvv/data/stop_times.tbl' WITH delimiter AS '|';
