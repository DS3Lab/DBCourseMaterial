COPY employees FROM '/employee/data/employees.tbl' WITH delimiter AS '|';
COPY departments FROM '/employee/data/departments.tbl' WITH delimiter AS '|';
COPY dept_manager FROM '/employee/data/dept_manager.tbl' WITH delimiter AS '|';
COPY dept_emp FROM '/employee/data/dept_emp.tbl' WITH delimiter AS '|';
COPY titles FROM '/employee/data/titles.tbl' WITH delimiter AS '|';
COPY salaries FROM '/employee/data/salaries.tbl' WITH delimiter AS '|';
