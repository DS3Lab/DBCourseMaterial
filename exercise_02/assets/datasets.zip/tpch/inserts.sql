COPY REGION FROM '/tpch/data/region.tbl' WITH DELIMITER AS '|';
COPY NATION FROM '/tpch/data/nation.tbl' WITH DELIMITER AS '|';
COPY PART FROM '/tpch/data/part.tbl' WITH DELIMITER AS '|';
COPY SUPPLIER FROM '/tpch/data/supplier.tbl' WITH DELIMITER AS '|';
COPY SUPPLYPART FROM '/tpch/data/supplypart.tbl' WITH DELIMITER AS '|';
COPY CUSTOMER FROM '/tpch/data/customer.tbl' WITH DELIMITER AS '|';
COPY ORDERS FROM '/tpch/data/orders.tbl' WITH DELIMITER AS '|';
COPY ORDERLINE FROM '/tpch/data/orderline.tbl' WITH DELIMITER AS '|';
